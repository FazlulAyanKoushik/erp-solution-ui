import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courier-statement',
  templateUrl: './courier-statement.component.html',
  styleUrls: ['./courier-statement.component.scss']
})
export class CourierStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
