import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aged-account-receivable',
  templateUrl: './aged-account-receivable.component.html',
  styleUrls: ['./aged-account-receivable.component.scss']
})
export class AgedAccountReceivableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
