import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todays-transaction-report',
  templateUrl: './todays-transaction-report.component.html',
  styleUrls: ['./todays-transaction-report.component.scss']
})
export class TodaysTransactionReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
