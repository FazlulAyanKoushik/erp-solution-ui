import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-collection',
  templateUrl: './customer-collection.component.html',
  styleUrls: ['./customer-collection.component.scss']
})
export class CustomerCollectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
