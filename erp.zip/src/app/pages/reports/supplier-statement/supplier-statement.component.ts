import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-statement',
  templateUrl: './supplier-statement.component.html',
  styleUrls: ['./supplier-statement.component.scss']
})
export class SupplierStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
