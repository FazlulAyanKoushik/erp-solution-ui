import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-month-to-date-sales',
  templateUrl: './month-to-date-sales.component.html',
  styleUrls: ['./month-to-date-sales.component.scss']
})
export class MonthToDateSalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
