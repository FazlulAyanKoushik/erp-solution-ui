import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-installments',
  templateUrl: './upcoming-installments.component.html',
  styleUrls: ['./upcoming-installments.component.scss']
})
export class UpcomingInstallmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
