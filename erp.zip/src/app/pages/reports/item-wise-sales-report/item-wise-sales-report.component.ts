import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-wise-sales-report',
  templateUrl: './item-wise-sales-report.component.html',
  styleUrls: ['./item-wise-sales-report.component.scss']
})
export class ItemWiseSalesReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
