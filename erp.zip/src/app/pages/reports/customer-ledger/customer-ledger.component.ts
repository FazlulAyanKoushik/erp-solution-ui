import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-ledger',
  templateUrl: './customer-ledger.component.html',
  styleUrls: ['./customer-ledger.component.scss']
})
export class CustomerLedgerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
