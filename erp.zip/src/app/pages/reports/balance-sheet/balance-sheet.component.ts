import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balance-sheet',
  templateUrl: './balance-sheet.component.html',
  styleUrls: ['./balance-sheet.component.scss']
})
export class BalanceSheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
