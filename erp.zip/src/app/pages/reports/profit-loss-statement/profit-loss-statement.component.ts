import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profit-loss-statement',
  templateUrl: './profit-loss-statement.component.html',
  styleUrls: ['./profit-loss-statement.component.scss']
})
export class ProfitLossStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
