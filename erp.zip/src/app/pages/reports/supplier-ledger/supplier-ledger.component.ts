import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-ledger',
  templateUrl: './supplier-ledger.component.html',
  styleUrls: ['./supplier-ledger.component.scss']
})
export class SupplierLedgerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
