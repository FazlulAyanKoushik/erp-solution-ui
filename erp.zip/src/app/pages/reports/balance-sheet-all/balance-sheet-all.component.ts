import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balance-sheet-all',
  templateUrl: './balance-sheet-all.component.html',
  styleUrls: ['./balance-sheet-all.component.scss']
})
export class BalanceSheetAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
