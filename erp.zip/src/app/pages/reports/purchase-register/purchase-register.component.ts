import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-register',
  templateUrl: './purchase-register.component.html',
  styleUrls: ['./purchase-register.component.scss']
})
export class PurchaseRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
