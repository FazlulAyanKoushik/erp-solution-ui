import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expense-detail-report',
  templateUrl: './expense-detail-report.component.html',
  styleUrls: ['./expense-detail-report.component.scss']
})
export class ExpenseDetailReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
