import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-register',
  templateUrl: './sales-register.component.html',
  styleUrls: ['./sales-register.component.scss']
})
export class SalesRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
