import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-wise-item-profit-report',
  templateUrl: './customer-wise-item-profit-report.component.html',
  styleUrls: ['./customer-wise-item-profit-report.component.scss']
})
export class CustomerWiseItemProfitReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
