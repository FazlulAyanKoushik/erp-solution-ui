import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tax-computation',
  templateUrl: './tax-computation.component.html',
  styleUrls: ['./tax-computation.component.scss']
})
export class TaxComputationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
