import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-report-all',
  templateUrl: './stock-report-all.component.html',
  styleUrls: ['./stock-report-all.component.scss']
})
export class StockReportAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
