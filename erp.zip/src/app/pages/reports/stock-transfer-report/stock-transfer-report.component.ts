import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-transfer-report',
  templateUrl: './stock-transfer-report.component.html',
  styleUrls: ['./stock-transfer-report.component.scss']
})
export class StockTransferReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
