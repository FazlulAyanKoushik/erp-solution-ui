import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-report',
  templateUrl: './stock-report.component.html',
  styleUrls: ['./stock-report.component.scss']
})
export class StockReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
