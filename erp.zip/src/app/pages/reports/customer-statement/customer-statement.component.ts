import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-statement',
  templateUrl: './customer-statement.component.html',
  styleUrls: ['./customer-statement.component.scss']
})
export class CustomerStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
