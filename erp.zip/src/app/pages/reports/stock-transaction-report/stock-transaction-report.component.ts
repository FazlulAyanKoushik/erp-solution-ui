import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-transaction-report',
  templateUrl: './stock-transaction-report.component.html',
  styleUrls: ['./stock-transaction-report.component.scss']
})
export class StockTransactionReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
