import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casier-wise-cash-summary-report',
  templateUrl: './casier-wise-cash-summary-report.component.html',
  styleUrls: ['./casier-wise-cash-summary-report.component.scss']
})
export class CasierWiseCashSummaryReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
