import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expense-summary-report',
  templateUrl: './expense-summary-report.component.html',
  styleUrls: ['./expense-summary-report.component.scss']
})
export class ExpenseSummaryReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
