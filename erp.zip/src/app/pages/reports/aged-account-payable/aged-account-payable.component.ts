import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aged-account-payable',
  templateUrl: './aged-account-payable.component.html',
  styleUrls: ['./aged-account-payable.component.scss']
})
export class AgedAccountPayableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
