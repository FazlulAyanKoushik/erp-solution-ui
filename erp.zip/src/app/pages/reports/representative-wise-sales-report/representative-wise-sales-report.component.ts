import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-representative-wise-sales-report',
  templateUrl: './representative-wise-sales-report.component.html',
  styleUrls: ['./representative-wise-sales-report.component.scss']
})
export class RepresentativeWiseSalesReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
