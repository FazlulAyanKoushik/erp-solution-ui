import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day-closing',
  templateUrl: './day-closing.component.html',
  styleUrls: ['./day-closing.component.scss']
})
export class DayClosingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
