import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-sale-summary',
  templateUrl: './item-sale-summary.component.html',
  styleUrls: ['./item-sale-summary.component.scss']
})
export class ItemSaleSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
