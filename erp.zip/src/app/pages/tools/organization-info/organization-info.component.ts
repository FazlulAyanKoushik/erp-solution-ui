import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organization-info',
  templateUrl: './organization-info.component.html',
  styleUrls: ['./organization-info.component.scss']
})
export class OrganizationInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
