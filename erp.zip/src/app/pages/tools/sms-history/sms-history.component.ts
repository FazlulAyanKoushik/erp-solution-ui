import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-history',
  templateUrl: './sms-history.component.html',
  styleUrls: ['./sms-history.component.scss']
})
export class SmsHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
