import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscription-invoice',
  templateUrl: './subscription-invoice.component.html',
  styleUrls: ['./subscription-invoice.component.scss']
})
export class SubscriptionInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
