import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bkash-agreements',
  templateUrl: './bkash-agreements.component.html',
  styleUrls: ['./bkash-agreements.component.scss']
})
export class BkashAgreementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
