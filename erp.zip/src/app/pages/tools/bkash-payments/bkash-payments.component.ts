import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bkash-payments',
  templateUrl: './bkash-payments.component.html',
  styleUrls: ['./bkash-payments.component.scss']
})
export class BkashPaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
