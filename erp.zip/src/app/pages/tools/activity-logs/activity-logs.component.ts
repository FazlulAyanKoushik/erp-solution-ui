import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-logs',
  templateUrl: './activity-logs.component.html',
  styleUrls: ['./activity-logs.component.scss']
})
export class ActivityLogsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
