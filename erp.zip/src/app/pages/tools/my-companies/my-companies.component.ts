import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-companies',
  templateUrl: './my-companies.component.html',
  styleUrls: ['./my-companies.component.scss']
})
export class MyCompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
