import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-cost-of-sales',
  templateUrl: './add-new-cost-of-sales.component.html',
  styleUrls: ['./add-new-cost-of-sales.component.scss']
})
export class AddNewCostOfSalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
