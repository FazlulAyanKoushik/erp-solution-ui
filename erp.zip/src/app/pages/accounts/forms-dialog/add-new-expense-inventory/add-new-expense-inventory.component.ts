import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-expense-inventory',
  templateUrl: './add-new-expense-inventory.component.html',
  styleUrls: ['./add-new-expense-inventory.component.scss']
})
export class AddNewExpenseInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
