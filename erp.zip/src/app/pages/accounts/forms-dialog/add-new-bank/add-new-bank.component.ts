import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-bank',
  templateUrl: './add-new-bank.component.html',
  styleUrls: ['./add-new-bank.component.scss']
})
export class AddNewBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
