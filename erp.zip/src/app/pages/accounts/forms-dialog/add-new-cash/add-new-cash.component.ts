import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-cash',
  templateUrl: './add-new-cash.component.html',
  styleUrls: ['./add-new-cash.component.scss']
})
export class AddNewCashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
