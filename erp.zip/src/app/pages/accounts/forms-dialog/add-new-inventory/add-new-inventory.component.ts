import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-inventory',
  templateUrl: './add-new-inventory.component.html',
  styleUrls: ['./add-new-inventory.component.scss']
})
export class AddNewInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
