import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-purchase',
  templateUrl: './add-new-purchase.component.html',
  styleUrls: ['./add-new-purchase.component.scss']
})
export class AddNewPurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
