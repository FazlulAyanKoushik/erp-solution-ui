import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-payable',
  templateUrl: './add-new-payable.component.html',
  styleUrls: ['./add-new-payable.component.scss']
})
export class AddNewPayableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
