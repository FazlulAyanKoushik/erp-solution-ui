import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-tax',
  templateUrl: './add-new-tax.component.html',
  styleUrls: ['./add-new-tax.component.scss']
})
export class AddNewTaxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
