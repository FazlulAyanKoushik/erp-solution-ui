import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-income',
  templateUrl: './add-new-income.component.html',
  styleUrls: ['./add-new-income.component.scss']
})
export class AddNewIncomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
