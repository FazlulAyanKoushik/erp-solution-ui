import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-equipment',
  templateUrl: './add-new-equipment.component.html',
  styleUrls: ['./add-new-equipment.component.scss']
})
export class AddNewEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
