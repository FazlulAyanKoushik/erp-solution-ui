import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-sale',
  templateUrl: './add-new-sale.component.html',
  styleUrls: ['./add-new-sale.component.scss']
})
export class AddNewSaleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
