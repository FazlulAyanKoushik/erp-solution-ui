import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-revinue',
  templateUrl: './add-new-revinue.component.html',
  styleUrls: ['./add-new-revinue.component.scss']
})
export class AddNewRevinueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
