import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-receivable',
  templateUrl: './add-new-receivable.component.html',
  styleUrls: ['./add-new-receivable.component.scss']
})
export class AddNewReceivableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
