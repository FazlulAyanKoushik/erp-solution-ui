import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-equity',
  templateUrl: './add-new-equity.component.html',
  styleUrls: ['./add-new-equity.component.scss']
})
export class AddNewEquityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
