import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-mobile-bank',
  templateUrl: './add-new-mobile-bank.component.html',
  styleUrls: ['./add-new-mobile-bank.component.scss']
})
export class AddNewMobileBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
