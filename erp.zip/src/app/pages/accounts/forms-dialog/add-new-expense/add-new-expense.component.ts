import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-expense',
  templateUrl: './add-new-expense.component.html',
  styleUrls: ['./add-new-expense.component.scss']
})
export class AddNewExpenseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
