import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-quotation',
  templateUrl: './make-quotation.component.html',
  styleUrls: ['./make-quotation.component.scss']
})
export class MakeQuotationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
