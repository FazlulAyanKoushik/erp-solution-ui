import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-sale',
  templateUrl: './make-sale.component.html',
  styleUrls: ['./make-sale.component.scss']
})
export class MakeSaleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
