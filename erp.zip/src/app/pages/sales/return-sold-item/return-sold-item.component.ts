import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-sold-item',
  templateUrl: './return-sold-item.component.html',
  styleUrls: ['./return-sold-item.component.scss']
})
export class ReturnSoldItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
