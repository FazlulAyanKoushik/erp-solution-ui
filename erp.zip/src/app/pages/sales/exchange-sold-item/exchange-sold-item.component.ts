import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exchange-sold-item',
  templateUrl: './exchange-sold-item.component.html',
  styleUrls: ['./exchange-sold-item.component.scss']
})
export class ExchangeSoldItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
