import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-return',
  templateUrl: './purchase-return.component.html',
  styleUrls: ['./purchase-return.component.scss']
})
export class PurchaseReturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
