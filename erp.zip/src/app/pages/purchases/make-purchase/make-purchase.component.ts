import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-purchase',
  templateUrl: './make-purchase.component.html',
  styleUrls: ['./make-purchase.component.scss']
})
export class MakePurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
