import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-purchase-order',
  templateUrl: './make-purchase-order.component.html',
  styleUrls: ['./make-purchase-order.component.scss']
})
export class MakePurchaseOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
