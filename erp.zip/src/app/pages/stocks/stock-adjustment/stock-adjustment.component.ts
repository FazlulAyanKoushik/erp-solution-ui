import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-adjustment',
  templateUrl: './stock-adjustment.component.html',
  styleUrls: ['./stock-adjustment.component.scss']
})
export class StockAdjustmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
