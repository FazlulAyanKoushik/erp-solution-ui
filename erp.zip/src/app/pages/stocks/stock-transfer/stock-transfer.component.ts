import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-transfer',
  templateUrl: './stock-transfer.component.html',
  styleUrls: ['./stock-transfer.component.scss']
})
export class StockTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
