import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clearing-cheque',
  templateUrl: './clearing-cheque.component.html',
  styleUrls: ['./clearing-cheque.component.scss']
})
export class ClearingChequeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
