import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-categories',
  templateUrl: './item-categories.component.html',
  styleUrls: ['./item-categories.component.scss']
})
export class ItemCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
