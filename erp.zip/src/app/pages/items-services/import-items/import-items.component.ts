import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-items',
  templateUrl: './import-items.component.html',
  styleUrls: ['./import-items.component.scss']
})
export class ImportItemsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
