import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-barcode',
  templateUrl: './print-barcode.component.html',
  styleUrls: ['./print-barcode.component.scss']
})
export class PrintBarcodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
