import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-measurement-units',
  templateUrl: './measurement-units.component.html',
  styleUrls: ['./measurement-units.component.scss']
})
export class MeasurementUnitsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
