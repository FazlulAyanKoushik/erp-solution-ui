import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-location',
  templateUrl: './item-location.component.html',
  styleUrls: ['./item-location.component.scss']
})
export class ItemLocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
