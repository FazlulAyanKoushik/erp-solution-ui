import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provided',
  templateUrl: './provided.component.html',
  styleUrls: ['./provided.component.scss']
})
export class ProvidedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
