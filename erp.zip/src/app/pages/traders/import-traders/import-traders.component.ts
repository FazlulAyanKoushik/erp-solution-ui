import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-traders',
  templateUrl: './import-traders.component.html',
  styleUrls: ['./import-traders.component.scss']
})
export class ImportTradersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
