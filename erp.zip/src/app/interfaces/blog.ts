export interface Blog {
    _id?:string,
    date:string,
    referance?:string,
    in:string,
    out:string,
    balance:string,
    selected?:boolean,
}
